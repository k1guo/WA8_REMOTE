//
//  File.swift
//  WA8
//
//  Created by 郭 on 2023/11/15.
//

import Foundation

protocol ProgressSpinnerDelegate{
    func showActivityIndicator()
    func hideActivityIndicator()
}
