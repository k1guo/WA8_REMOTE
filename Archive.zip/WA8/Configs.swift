//
//  Configs.swift
//  WA8
//
//  Created by 郭 on 2023/11/15.
//

import Foundation

class Configs{
    static let tableViewContactsID = "tableViewContactsID"
}
